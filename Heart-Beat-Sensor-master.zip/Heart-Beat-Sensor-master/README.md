# Heart-Beat-Sensor
Heart beat calculation using AVR
